                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ANSI-C Compiler
                                      3 ; Version 4.2.0 #13081 (MINGW64)
                                      4 ;--------------------------------------------------------
                                      5 	.module i2c
                                      6 	.optsdcc -mmcs51 --model-small
                                      7 	
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _i2c_clock
                                     12 	.globl _CCF0
                                     13 	.globl _CCF1
                                     14 	.globl _CCF2
                                     15 	.globl _CR
                                     16 	.globl _CF
                                     17 	.globl _RI
                                     18 	.globl _TI
                                     19 	.globl _RB8
                                     20 	.globl _TB8
                                     21 	.globl _REN
                                     22 	.globl _SM2
                                     23 	.globl _SM1
                                     24 	.globl _SM0
                                     25 	.globl _IT0
                                     26 	.globl _IE0
                                     27 	.globl _IT1
                                     28 	.globl _IE1
                                     29 	.globl _TR0
                                     30 	.globl _TF0
                                     31 	.globl _TR1
                                     32 	.globl _TF1
                                     33 	.globl _PX0
                                     34 	.globl _PT0
                                     35 	.globl _PX1
                                     36 	.globl _PT1
                                     37 	.globl _PS
                                     38 	.globl _PADC
                                     39 	.globl _PLVD
                                     40 	.globl _PPCA
                                     41 	.globl _EX0
                                     42 	.globl _ET0
                                     43 	.globl _EX1
                                     44 	.globl _ET1
                                     45 	.globl _ES
                                     46 	.globl _EADC
                                     47 	.globl _ELVD
                                     48 	.globl _EA
                                     49 	.globl _P77
                                     50 	.globl _P76
                                     51 	.globl _P75
                                     52 	.globl _P74
                                     53 	.globl _P73
                                     54 	.globl _P72
                                     55 	.globl _P71
                                     56 	.globl _P70
                                     57 	.globl _P67
                                     58 	.globl _P66
                                     59 	.globl _P65
                                     60 	.globl _P64
                                     61 	.globl _P63
                                     62 	.globl _P62
                                     63 	.globl _P61
                                     64 	.globl _P60
                                     65 	.globl _P57
                                     66 	.globl _P56
                                     67 	.globl _P55
                                     68 	.globl _P54
                                     69 	.globl _P53
                                     70 	.globl _P52
                                     71 	.globl _P51
                                     72 	.globl _P50
                                     73 	.globl _P47
                                     74 	.globl _P46
                                     75 	.globl _P45
                                     76 	.globl _P44
                                     77 	.globl _P43
                                     78 	.globl _P42
                                     79 	.globl _P41
                                     80 	.globl _P40
                                     81 	.globl _P37
                                     82 	.globl _P36
                                     83 	.globl _P35
                                     84 	.globl _P34
                                     85 	.globl _P33
                                     86 	.globl _P32
                                     87 	.globl _P31
                                     88 	.globl _P30
                                     89 	.globl _P27
                                     90 	.globl _P26
                                     91 	.globl _P25
                                     92 	.globl _P24
                                     93 	.globl _P23
                                     94 	.globl _P22
                                     95 	.globl _P21
                                     96 	.globl _P20
                                     97 	.globl _P17
                                     98 	.globl _P16
                                     99 	.globl _P15
                                    100 	.globl _P14
                                    101 	.globl _P13
                                    102 	.globl _P12
                                    103 	.globl _P11
                                    104 	.globl _P10
                                    105 	.globl _P07
                                    106 	.globl _P06
                                    107 	.globl _P05
                                    108 	.globl _P04
                                    109 	.globl _P03
                                    110 	.globl _P02
                                    111 	.globl _P01
                                    112 	.globl _P00
                                    113 	.globl _P
                                    114 	.globl _F1
                                    115 	.globl _OV
                                    116 	.globl _RS0
                                    117 	.globl _RS1
                                    118 	.globl _F0
                                    119 	.globl _AC
                                    120 	.globl _CY
                                    121 	.globl _PWMFDCR
                                    122 	.globl _PWMIF
                                    123 	.globl _PWMCR
                                    124 	.globl _PWMCFG
                                    125 	.globl _CMPCR2
                                    126 	.globl _CMPCR1
                                    127 	.globl _CCAP2H
                                    128 	.globl _CCAP1H
                                    129 	.globl _CCAP0H
                                    130 	.globl _PCA_PWM2
                                    131 	.globl _PCA_PWM1
                                    132 	.globl _PCA_PWM0
                                    133 	.globl _CCAP2L
                                    134 	.globl _CCAP1L
                                    135 	.globl _CCAP0L
                                    136 	.globl _CCAPM2
                                    137 	.globl _CCAPM1
                                    138 	.globl _CCAPM0
                                    139 	.globl _CH
                                    140 	.globl _CL
                                    141 	.globl _CMOD
                                    142 	.globl _CCON
                                    143 	.globl _IAP_CONTR
                                    144 	.globl _IAP_TRIG
                                    145 	.globl _IAP_CMD
                                    146 	.globl _IAP_ADDRL
                                    147 	.globl _IAP_ADDRH
                                    148 	.globl _IAP_DATA
                                    149 	.globl _SPDAT
                                    150 	.globl _SPCTL
                                    151 	.globl _SPSTAT
                                    152 	.globl _ADC_RESL
                                    153 	.globl _ADC_RES
                                    154 	.globl _ADC_CONTR
                                    155 	.globl _SADEN
                                    156 	.globl _SADDR
                                    157 	.globl _S4BUF
                                    158 	.globl _S4CON
                                    159 	.globl _S3BUF
                                    160 	.globl _S3CON
                                    161 	.globl _S2BUF
                                    162 	.globl _S2CON
                                    163 	.globl _SBUF
                                    164 	.globl _SCON
                                    165 	.globl _WDT_CONTR
                                    166 	.globl _WKTCH
                                    167 	.globl _WKTCL
                                    168 	.globl _T2L
                                    169 	.globl _T2H
                                    170 	.globl _T3L
                                    171 	.globl _T3H
                                    172 	.globl _T4L
                                    173 	.globl _T4H
                                    174 	.globl _T4T3M
                                    175 	.globl _TH1
                                    176 	.globl _TH0
                                    177 	.globl _TL1
                                    178 	.globl _TL0
                                    179 	.globl _TMOD
                                    180 	.globl _TCON
                                    181 	.globl _INT_CLKO
                                    182 	.globl _IP2
                                    183 	.globl _IE2
                                    184 	.globl _IP
                                    185 	.globl _IE
                                    186 	.globl _P_SW2
                                    187 	.globl _P1ASF
                                    188 	.globl _BUS_SPEED
                                    189 	.globl _CLK_DIV
                                    190 	.globl _P_SW1
                                    191 	.globl _AUXR1
                                    192 	.globl _AUXR
                                    193 	.globl _PCON
                                    194 	.globl _P7M1
                                    195 	.globl _P7M0
                                    196 	.globl _P6M1
                                    197 	.globl _P6M0
                                    198 	.globl _P5M1
                                    199 	.globl _P5M0
                                    200 	.globl _P4M1
                                    201 	.globl _P4M0
                                    202 	.globl _P3M1
                                    203 	.globl _P3M0
                                    204 	.globl _P2M1
                                    205 	.globl _P2M0
                                    206 	.globl _P1M1
                                    207 	.globl _P1M0
                                    208 	.globl _P0M1
                                    209 	.globl _P0M0
                                    210 	.globl _P7
                                    211 	.globl _P6
                                    212 	.globl _P5
                                    213 	.globl _P4
                                    214 	.globl _P3
                                    215 	.globl _P2
                                    216 	.globl _P1
                                    217 	.globl _P0
                                    218 	.globl _DPH
                                    219 	.globl _DPL
                                    220 	.globl _SP
                                    221 	.globl _PSW
                                    222 	.globl _B
                                    223 	.globl _ACC
                                    224 	.globl _i2c_read_PARM_1
                                    225 	.globl _i2c_start
                                    226 	.globl _i2c_stop
                                    227 	.globl _i2c_write
                                    228 	.globl _i2c_read
                                    229 ;--------------------------------------------------------
                                    230 ; special function registers
                                    231 ;--------------------------------------------------------
                                    232 	.area RSEG    (ABS,DATA)
      000000                        233 	.org 0x0000
                           0000E0   234 _ACC	=	0x00e0
                           0000F0   235 _B	=	0x00f0
                           0000D0   236 _PSW	=	0x00d0
                           000081   237 _SP	=	0x0081
                           000082   238 _DPL	=	0x0082
                           000083   239 _DPH	=	0x0083
                           000080   240 _P0	=	0x0080
                           000090   241 _P1	=	0x0090
                           0000A0   242 _P2	=	0x00a0
                           0000B0   243 _P3	=	0x00b0
                           0000C0   244 _P4	=	0x00c0
                           0000C8   245 _P5	=	0x00c8
                           0000E8   246 _P6	=	0x00e8
                           0000F8   247 _P7	=	0x00f8
                           000094   248 _P0M0	=	0x0094
                           000093   249 _P0M1	=	0x0093
                           000092   250 _P1M0	=	0x0092
                           000091   251 _P1M1	=	0x0091
                           000096   252 _P2M0	=	0x0096
                           000095   253 _P2M1	=	0x0095
                           0000B2   254 _P3M0	=	0x00b2
                           0000B1   255 _P3M1	=	0x00b1
                           0000B4   256 _P4M0	=	0x00b4
                           0000B3   257 _P4M1	=	0x00b3
                           0000CA   258 _P5M0	=	0x00ca
                           0000C9   259 _P5M1	=	0x00c9
                           0000CC   260 _P6M0	=	0x00cc
                           0000CB   261 _P6M1	=	0x00cb
                           0000E2   262 _P7M0	=	0x00e2
                           0000E1   263 _P7M1	=	0x00e1
                           000087   264 _PCON	=	0x0087
                           00008E   265 _AUXR	=	0x008e
                           0000A2   266 _AUXR1	=	0x00a2
                           0000A2   267 _P_SW1	=	0x00a2
                           000097   268 _CLK_DIV	=	0x0097
                           0000A1   269 _BUS_SPEED	=	0x00a1
                           00009D   270 _P1ASF	=	0x009d
                           0000BA   271 _P_SW2	=	0x00ba
                           0000A8   272 _IE	=	0x00a8
                           0000B8   273 _IP	=	0x00b8
                           0000AF   274 _IE2	=	0x00af
                           0000B5   275 _IP2	=	0x00b5
                           00008F   276 _INT_CLKO	=	0x008f
                           000088   277 _TCON	=	0x0088
                           000089   278 _TMOD	=	0x0089
                           00008A   279 _TL0	=	0x008a
                           00008B   280 _TL1	=	0x008b
                           00008C   281 _TH0	=	0x008c
                           00008D   282 _TH1	=	0x008d
                           0000D1   283 _T4T3M	=	0x00d1
                           0000D2   284 _T4H	=	0x00d2
                           0000D3   285 _T4L	=	0x00d3
                           0000D4   286 _T3H	=	0x00d4
                           0000D5   287 _T3L	=	0x00d5
                           0000D6   288 _T2H	=	0x00d6
                           0000D7   289 _T2L	=	0x00d7
                           0000AA   290 _WKTCL	=	0x00aa
                           0000AB   291 _WKTCH	=	0x00ab
                           0000C1   292 _WDT_CONTR	=	0x00c1
                           000098   293 _SCON	=	0x0098
                           000099   294 _SBUF	=	0x0099
                           00009A   295 _S2CON	=	0x009a
                           00009B   296 _S2BUF	=	0x009b
                           0000AC   297 _S3CON	=	0x00ac
                           0000AD   298 _S3BUF	=	0x00ad
                           000084   299 _S4CON	=	0x0084
                           000085   300 _S4BUF	=	0x0085
                           0000A9   301 _SADDR	=	0x00a9
                           0000B9   302 _SADEN	=	0x00b9
                           0000BC   303 _ADC_CONTR	=	0x00bc
                           0000BD   304 _ADC_RES	=	0x00bd
                           0000BE   305 _ADC_RESL	=	0x00be
                           0000CD   306 _SPSTAT	=	0x00cd
                           0000CE   307 _SPCTL	=	0x00ce
                           0000CF   308 _SPDAT	=	0x00cf
                           0000C2   309 _IAP_DATA	=	0x00c2
                           0000C3   310 _IAP_ADDRH	=	0x00c3
                           0000C4   311 _IAP_ADDRL	=	0x00c4
                           0000C5   312 _IAP_CMD	=	0x00c5
                           0000C6   313 _IAP_TRIG	=	0x00c6
                           0000C7   314 _IAP_CONTR	=	0x00c7
                           0000D8   315 _CCON	=	0x00d8
                           0000D9   316 _CMOD	=	0x00d9
                           0000E9   317 _CL	=	0x00e9
                           0000F9   318 _CH	=	0x00f9
                           0000DA   319 _CCAPM0	=	0x00da
                           0000DB   320 _CCAPM1	=	0x00db
                           0000DC   321 _CCAPM2	=	0x00dc
                           0000EA   322 _CCAP0L	=	0x00ea
                           0000EB   323 _CCAP1L	=	0x00eb
                           0000EC   324 _CCAP2L	=	0x00ec
                           0000F2   325 _PCA_PWM0	=	0x00f2
                           0000F3   326 _PCA_PWM1	=	0x00f3
                           0000F4   327 _PCA_PWM2	=	0x00f4
                           0000FA   328 _CCAP0H	=	0x00fa
                           0000FB   329 _CCAP1H	=	0x00fb
                           0000FC   330 _CCAP2H	=	0x00fc
                           0000E6   331 _CMPCR1	=	0x00e6
                           0000E7   332 _CMPCR2	=	0x00e7
                           0000F1   333 _PWMCFG	=	0x00f1
                           0000F5   334 _PWMCR	=	0x00f5
                           0000F6   335 _PWMIF	=	0x00f6
                           0000F7   336 _PWMFDCR	=	0x00f7
                                    337 ;--------------------------------------------------------
                                    338 ; special function bits
                                    339 ;--------------------------------------------------------
                                    340 	.area RSEG    (ABS,DATA)
      000000                        341 	.org 0x0000
                           0000D7   342 _CY	=	0x00d7
                           0000D6   343 _AC	=	0x00d6
                           0000D5   344 _F0	=	0x00d5
                           0000D4   345 _RS1	=	0x00d4
                           0000D3   346 _RS0	=	0x00d3
                           0000D2   347 _OV	=	0x00d2
                           0000D1   348 _F1	=	0x00d1
                           0000D0   349 _P	=	0x00d0
                           000080   350 _P00	=	0x0080
                           000081   351 _P01	=	0x0081
                           000082   352 _P02	=	0x0082
                           000083   353 _P03	=	0x0083
                           000084   354 _P04	=	0x0084
                           000085   355 _P05	=	0x0085
                           000086   356 _P06	=	0x0086
                           000087   357 _P07	=	0x0087
                           000090   358 _P10	=	0x0090
                           000091   359 _P11	=	0x0091
                           000092   360 _P12	=	0x0092
                           000093   361 _P13	=	0x0093
                           000094   362 _P14	=	0x0094
                           000095   363 _P15	=	0x0095
                           000096   364 _P16	=	0x0096
                           000097   365 _P17	=	0x0097
                           0000A0   366 _P20	=	0x00a0
                           0000A1   367 _P21	=	0x00a1
                           0000A2   368 _P22	=	0x00a2
                           0000A3   369 _P23	=	0x00a3
                           0000A4   370 _P24	=	0x00a4
                           0000A5   371 _P25	=	0x00a5
                           0000A6   372 _P26	=	0x00a6
                           0000A7   373 _P27	=	0x00a7
                           0000B0   374 _P30	=	0x00b0
                           0000B1   375 _P31	=	0x00b1
                           0000B2   376 _P32	=	0x00b2
                           0000B3   377 _P33	=	0x00b3
                           0000B4   378 _P34	=	0x00b4
                           0000B5   379 _P35	=	0x00b5
                           0000B6   380 _P36	=	0x00b6
                           0000B7   381 _P37	=	0x00b7
                           0000C0   382 _P40	=	0x00c0
                           0000C1   383 _P41	=	0x00c1
                           0000C2   384 _P42	=	0x00c2
                           0000C3   385 _P43	=	0x00c3
                           0000C4   386 _P44	=	0x00c4
                           0000C5   387 _P45	=	0x00c5
                           0000C6   388 _P46	=	0x00c6
                           0000C7   389 _P47	=	0x00c7
                           0000C8   390 _P50	=	0x00c8
                           0000C9   391 _P51	=	0x00c9
                           0000CA   392 _P52	=	0x00ca
                           0000CB   393 _P53	=	0x00cb
                           0000CC   394 _P54	=	0x00cc
                           0000CD   395 _P55	=	0x00cd
                           0000CE   396 _P56	=	0x00ce
                           0000CF   397 _P57	=	0x00cf
                           0000E8   398 _P60	=	0x00e8
                           0000E9   399 _P61	=	0x00e9
                           0000EA   400 _P62	=	0x00ea
                           0000EB   401 _P63	=	0x00eb
                           0000EC   402 _P64	=	0x00ec
                           0000ED   403 _P65	=	0x00ed
                           0000EE   404 _P66	=	0x00ee
                           0000EF   405 _P67	=	0x00ef
                           0000F8   406 _P70	=	0x00f8
                           0000F9   407 _P71	=	0x00f9
                           0000FA   408 _P72	=	0x00fa
                           0000FB   409 _P73	=	0x00fb
                           0000FC   410 _P74	=	0x00fc
                           0000FD   411 _P75	=	0x00fd
                           0000FE   412 _P76	=	0x00fe
                           0000FF   413 _P77	=	0x00ff
                           0000AF   414 _EA	=	0x00af
                           0000AE   415 _ELVD	=	0x00ae
                           0000AD   416 _EADC	=	0x00ad
                           0000AC   417 _ES	=	0x00ac
                           0000AB   418 _ET1	=	0x00ab
                           0000AA   419 _EX1	=	0x00aa
                           0000A9   420 _ET0	=	0x00a9
                           0000A8   421 _EX0	=	0x00a8
                           0000BF   422 _PPCA	=	0x00bf
                           0000BE   423 _PLVD	=	0x00be
                           0000BD   424 _PADC	=	0x00bd
                           0000BC   425 _PS	=	0x00bc
                           0000BB   426 _PT1	=	0x00bb
                           0000BA   427 _PX1	=	0x00ba
                           0000B9   428 _PT0	=	0x00b9
                           0000B8   429 _PX0	=	0x00b8
                           00008F   430 _TF1	=	0x008f
                           00008E   431 _TR1	=	0x008e
                           00008D   432 _TF0	=	0x008d
                           00008C   433 _TR0	=	0x008c
                           00008B   434 _IE1	=	0x008b
                           00008A   435 _IT1	=	0x008a
                           000089   436 _IE0	=	0x0089
                           000088   437 _IT0	=	0x0088
                           00009F   438 _SM0	=	0x009f
                           00009E   439 _SM1	=	0x009e
                           00009D   440 _SM2	=	0x009d
                           00009C   441 _REN	=	0x009c
                           00009B   442 _TB8	=	0x009b
                           00009A   443 _RB8	=	0x009a
                           000099   444 _TI	=	0x0099
                           000098   445 _RI	=	0x0098
                           0000DF   446 _CF	=	0x00df
                           0000DE   447 _CR	=	0x00de
                           0000DA   448 _CCF2	=	0x00da
                           0000D9   449 _CCF1	=	0x00d9
                           0000D8   450 _CCF0	=	0x00d8
                                    451 ;--------------------------------------------------------
                                    452 ; overlayable register banks
                                    453 ;--------------------------------------------------------
                                    454 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        455 	.ds 8
                                    456 ;--------------------------------------------------------
                                    457 ; internal ram data
                                    458 ;--------------------------------------------------------
                                    459 	.area DSEG    (DATA)
                                    460 ;--------------------------------------------------------
                                    461 ; overlayable items in internal ram
                                    462 ;--------------------------------------------------------
                                    463 ;--------------------------------------------------------
                                    464 ; indirectly addressable internal ram data
                                    465 ;--------------------------------------------------------
                                    466 	.area ISEG    (DATA)
                                    467 ;--------------------------------------------------------
                                    468 ; absolute internal ram data
                                    469 ;--------------------------------------------------------
                                    470 	.area IABS    (ABS,DATA)
                                    471 	.area IABS    (ABS,DATA)
                                    472 ;--------------------------------------------------------
                                    473 ; bit data
                                    474 ;--------------------------------------------------------
                                    475 	.area BSEG    (BIT)
      000000                        476 _i2c_read_PARM_1:
      000000                        477 	.ds 1
                                    478 ;--------------------------------------------------------
                                    479 ; paged external ram data
                                    480 ;--------------------------------------------------------
                                    481 	.area PSEG    (PAG,XDATA)
                                    482 ;--------------------------------------------------------
                                    483 ; external ram data
                                    484 ;--------------------------------------------------------
                                    485 	.area XSEG    (XDATA)
                                    486 ;--------------------------------------------------------
                                    487 ; absolute external ram data
                                    488 ;--------------------------------------------------------
                                    489 	.area XABS    (ABS,XDATA)
                                    490 ;--------------------------------------------------------
                                    491 ; external initialized ram data
                                    492 ;--------------------------------------------------------
                                    493 	.area XISEG   (XDATA)
                                    494 	.area HOME    (CODE)
                                    495 	.area GSINIT0 (CODE)
                                    496 	.area GSINIT1 (CODE)
                                    497 	.area GSINIT2 (CODE)
                                    498 	.area GSINIT3 (CODE)
                                    499 	.area GSINIT4 (CODE)
                                    500 	.area GSINIT5 (CODE)
                                    501 	.area GSINIT  (CODE)
                                    502 	.area GSFINAL (CODE)
                                    503 	.area CSEG    (CODE)
                                    504 ;--------------------------------------------------------
                                    505 ; global & static initialisations
                                    506 ;--------------------------------------------------------
                                    507 	.area HOME    (CODE)
                                    508 	.area GSINIT  (CODE)
                                    509 	.area GSFINAL (CODE)
                                    510 	.area GSINIT  (CODE)
                                    511 ;--------------------------------------------------------
                                    512 ; Home
                                    513 ;--------------------------------------------------------
                                    514 	.area HOME    (CODE)
                                    515 	.area HOME    (CODE)
                                    516 ;--------------------------------------------------------
                                    517 ; code
                                    518 ;--------------------------------------------------------
                                    519 	.area CSEG    (CODE)
                                    520 ;------------------------------------------------------------
                                    521 ;Allocation info for local variables in function 'i2c_start'
                                    522 ;------------------------------------------------------------
                                    523 ;	src\i2c.c:3: void i2c_start(){
                                    524 ;	-----------------------------------------
                                    525 ;	 function i2c_start
                                    526 ;	-----------------------------------------
      0003EB                        527 _i2c_start:
                           000007   528 	ar7 = 0x07
                           000006   529 	ar6 = 0x06
                           000005   530 	ar5 = 0x05
                           000004   531 	ar4 = 0x04
                           000003   532 	ar3 = 0x03
                           000002   533 	ar2 = 0x02
                           000001   534 	ar1 = 0x01
                           000000   535 	ar0 = 0x00
                                    536 ;	src\i2c.c:4: sda_bit = 1;
                                    537 ;	assignBit
      0003EB D2 C0            [12]  538 	setb	_P40
                                    539 ;	src\i2c.c:5: WATCHDOG;WATCHDOG;
      0003ED 43 C1 10         [24]  540 	orl	_WDT_CONTR,#0x10
      0003F0 43 C1 10         [24]  541 	orl	_WDT_CONTR,#0x10
                                    542 ;	src\i2c.c:6: scl_bit = 1;
                                    543 ;	assignBit
      0003F3 D2 CD            [12]  544 	setb	_P55
                                    545 ;	src\i2c.c:7: WATCHDOG;WATCHDOG;
      0003F5 43 C1 10         [24]  546 	orl	_WDT_CONTR,#0x10
      0003F8 43 C1 10         [24]  547 	orl	_WDT_CONTR,#0x10
                                    548 ;	src\i2c.c:8: sda_bit=0;
                                    549 ;	assignBit
      0003FB C2 C0            [12]  550 	clr	_P40
                                    551 ;	src\i2c.c:9: WATCHDOG;WATCHDOG;
      0003FD 43 C1 10         [24]  552 	orl	_WDT_CONTR,#0x10
      000400 43 C1 10         [24]  553 	orl	_WDT_CONTR,#0x10
                                    554 ;	src\i2c.c:10: scl_bit=0;
                                    555 ;	assignBit
      000403 C2 CD            [12]  556 	clr	_P55
                                    557 ;	src\i2c.c:11: }
      000405 22               [24]  558 	ret
                                    559 ;------------------------------------------------------------
                                    560 ;Allocation info for local variables in function 'i2c_stop'
                                    561 ;------------------------------------------------------------
                                    562 ;	src\i2c.c:13: void i2c_stop(){
                                    563 ;	-----------------------------------------
                                    564 ;	 function i2c_stop
                                    565 ;	-----------------------------------------
      000406                        566 _i2c_stop:
                                    567 ;	src\i2c.c:14: sda_bit = 0;
                                    568 ;	assignBit
      000406 C2 C0            [12]  569 	clr	_P40
                                    570 ;	src\i2c.c:15: WATCHDOG;WATCHDOG;
      000408 43 C1 10         [24]  571 	orl	_WDT_CONTR,#0x10
      00040B 43 C1 10         [24]  572 	orl	_WDT_CONTR,#0x10
                                    573 ;	src\i2c.c:16: scl_bit = 1;
                                    574 ;	assignBit
      00040E D2 CD            [12]  575 	setb	_P55
                                    576 ;	src\i2c.c:17: WATCHDOG;WATCHDOG;
      000410 43 C1 10         [24]  577 	orl	_WDT_CONTR,#0x10
      000413 43 C1 10         [24]  578 	orl	_WDT_CONTR,#0x10
                                    579 ;	src\i2c.c:18: sda_bit  = 1;
                                    580 ;	assignBit
      000416 D2 C0            [12]  581 	setb	_P40
                                    582 ;	src\i2c.c:19: }
      000418 22               [24]  583 	ret
                                    584 ;------------------------------------------------------------
                                    585 ;Allocation info for local variables in function 'i2c_clock'
                                    586 ;------------------------------------------------------------
                                    587 ;	src\i2c.c:20: void i2c_clock(){
                                    588 ;	-----------------------------------------
                                    589 ;	 function i2c_clock
                                    590 ;	-----------------------------------------
      000419                        591 _i2c_clock:
                                    592 ;	src\i2c.c:21: WATCHDOG;WATCHDOG;
      000419 43 C1 10         [24]  593 	orl	_WDT_CONTR,#0x10
      00041C 43 C1 10         [24]  594 	orl	_WDT_CONTR,#0x10
                                    595 ;	src\i2c.c:22: scl_bit = 1;
                                    596 ;	assignBit
      00041F D2 CD            [12]  597 	setb	_P55
                                    598 ;	src\i2c.c:23: WATCHDOG;WATCHDOG;
      000421 43 C1 10         [24]  599 	orl	_WDT_CONTR,#0x10
      000424 43 C1 10         [24]  600 	orl	_WDT_CONTR,#0x10
                                    601 ;	src\i2c.c:24: scl_bit = 0;
                                    602 ;	assignBit
      000427 C2 CD            [12]  603 	clr	_P55
                                    604 ;	src\i2c.c:25: }
      000429 22               [24]  605 	ret
                                    606 ;------------------------------------------------------------
                                    607 ;Allocation info for local variables in function 'i2c_write'
                                    608 ;------------------------------------------------------------
                                    609 ;dulieu                    Allocated to registers r7 
                                    610 ;i                         Allocated to registers r6 
                                    611 ;------------------------------------------------------------
                                    612 ;	src\i2c.c:27: void i2c_write(u8 dulieu){
                                    613 ;	-----------------------------------------
                                    614 ;	 function i2c_write
                                    615 ;	-----------------------------------------
      00042A                        616 _i2c_write:
      00042A AF 82            [24]  617 	mov	r7,dpl
                                    618 ;	src\i2c.c:29: for(i=0;i<8;i++){
      00042C 7E 00            [12]  619 	mov	r6,#0x00
      00042E                        620 00102$:
                                    621 ;	src\i2c.c:30: sda_bit = dulieu & 0x80;
      00042E EF               [12]  622 	mov	a,r7
      00042F 23               [12]  623 	rl	a
      000430 54 01            [12]  624 	anl	a,#0x01
                                    625 ;	assignBit
      000432 24 FF            [12]  626 	add	a,#0xff
      000434 92 C0            [24]  627 	mov	_P40,c
                                    628 ;	src\i2c.c:31: dulieu <<= 1;
      000436 8F 05            [24]  629 	mov	ar5,r7
      000438 ED               [12]  630 	mov	a,r5
      000439 2D               [12]  631 	add	a,r5
      00043A FF               [12]  632 	mov	r7,a
                                    633 ;	src\i2c.c:32: i2c_clock();
      00043B C0 07            [24]  634 	push	ar7
      00043D C0 06            [24]  635 	push	ar6
      00043F 12 04 19         [24]  636 	lcall	_i2c_clock
      000442 D0 06            [24]  637 	pop	ar6
      000444 D0 07            [24]  638 	pop	ar7
                                    639 ;	src\i2c.c:29: for(i=0;i<8;i++){
      000446 0E               [12]  640 	inc	r6
      000447 BE 08 00         [24]  641 	cjne	r6,#0x08,00115$
      00044A                        642 00115$:
      00044A 40 E2            [24]  643 	jc	00102$
                                    644 ;	src\i2c.c:34: i2c_clock();//receive ACK
                                    645 ;	src\i2c.c:35: }
      00044C 02 04 19         [24]  646 	ljmp	_i2c_clock
                                    647 ;------------------------------------------------------------
                                    648 ;Allocation info for local variables in function 'i2c_read'
                                    649 ;------------------------------------------------------------
                                    650 ;i                         Allocated to registers r6 
                                    651 ;dulieu                    Allocated to registers r5 
                                    652 ;------------------------------------------------------------
                                    653 ;	src\i2c.c:37: u8 i2c_read(__bit i2c_ack){
                                    654 ;	-----------------------------------------
                                    655 ;	 function i2c_read
                                    656 ;	-----------------------------------------
      00044F                        657 _i2c_read:
                                    658 ;	src\i2c.c:38: u8 i,dulieu=0;
      00044F 7F 00            [12]  659 	mov	r7,#0x00
                                    660 ;	src\i2c.c:39: sda_bit = 1;
                                    661 ;	assignBit
      000451 D2 C0            [12]  662 	setb	_P40
                                    663 ;	src\i2c.c:40: for(i=0;i<8;i++){
      000453 7E 00            [12]  664 	mov	r6,#0x00
      000455                        665 00102$:
                                    666 ;	src\i2c.c:41: WATCHDOG;WATCHDOG;
      000455 43 C1 10         [24]  667 	orl	_WDT_CONTR,#0x10
      000458 43 C1 10         [24]  668 	orl	_WDT_CONTR,#0x10
                                    669 ;	src\i2c.c:42: scl_bit = 1;
                                    670 ;	assignBit
      00045B D2 CD            [12]  671 	setb	_P55
                                    672 ;	src\i2c.c:43: WATCHDOG;WATCHDOG;
      00045D 43 C1 10         [24]  673 	orl	_WDT_CONTR,#0x10
      000460 43 C1 10         [24]  674 	orl	_WDT_CONTR,#0x10
                                    675 ;	src\i2c.c:44: dulieu<<=1;
      000463 8F 05            [24]  676 	mov	ar5,r7
      000465 ED               [12]  677 	mov	a,r5
      000466 2D               [12]  678 	add	a,r5
      000467 FD               [12]  679 	mov	r5,a
                                    680 ;	src\i2c.c:45: dulieu |= sda_bit;
      000468 A2 C0            [12]  681 	mov	c,_P40
      00046A E4               [12]  682 	clr	a
      00046B 33               [12]  683 	rlc	a
      00046C 4D               [12]  684 	orl	a,r5
      00046D FF               [12]  685 	mov	r7,a
                                    686 ;	src\i2c.c:46: scl_bit = 0;
                                    687 ;	assignBit
      00046E C2 CD            [12]  688 	clr	_P55
                                    689 ;	src\i2c.c:40: for(i=0;i<8;i++){
      000470 0E               [12]  690 	inc	r6
      000471 BE 08 00         [24]  691 	cjne	r6,#0x08,00117$
      000474                        692 00117$:
      000474 40 DF            [24]  693 	jc	00102$
                                    694 ;	src\i2c.c:48: sda_bit = !i2c_ack;
      000476 A2 00            [12]  695 	mov	c,_i2c_read_PARM_1
      000478 B3               [12]  696 	cpl	c
      000479 92 C0            [24]  697 	mov	_P40,c
                                    698 ;	src\i2c.c:49: i2c_clock();
      00047B C0 07            [24]  699 	push	ar7
      00047D 12 04 19         [24]  700 	lcall	_i2c_clock
      000480 D0 07            [24]  701 	pop	ar7
                                    702 ;	src\i2c.c:50: scl_bit = sda_bit;
                                    703 ;	assignBit
      000482 A2 C0            [12]  704 	mov	c,_P40
      000484 92 CD            [24]  705 	mov	_P55,c
                                    706 ;	src\i2c.c:51: return dulieu;
      000486 8F 82            [24]  707 	mov	dpl,r7
                                    708 ;	src\i2c.c:52: }
      000488 22               [24]  709 	ret
                                    710 	.area CSEG    (CODE)
                                    711 	.area CONST   (CODE)
                                    712 	.area XINIT   (CODE)
                                    713 	.area CABS    (ABS,CODE)
